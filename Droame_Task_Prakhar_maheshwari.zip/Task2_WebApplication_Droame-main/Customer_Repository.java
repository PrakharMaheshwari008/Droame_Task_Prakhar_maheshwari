package com.Droame.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Droame.entity.Customer_Details;

public interface Customer_Repository extends JpaRepository<Customer_Details, Integer> {


}
