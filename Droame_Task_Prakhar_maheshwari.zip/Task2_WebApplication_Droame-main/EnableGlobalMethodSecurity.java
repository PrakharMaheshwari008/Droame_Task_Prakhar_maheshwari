package com.Droame.config;

public @interface EnableGlobalMethodSecurity {

	boolean jsr250Enabled();

}
